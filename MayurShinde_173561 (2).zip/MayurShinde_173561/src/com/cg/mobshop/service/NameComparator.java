package com.cg.mobshop.service;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class NameComparator implements Comparator<Mobiles> {

	@Override
	public int compare(Mobiles o1, Mobiles o2) {
		return o1.getName().compareTo(o2.getName());
	}

	
}
