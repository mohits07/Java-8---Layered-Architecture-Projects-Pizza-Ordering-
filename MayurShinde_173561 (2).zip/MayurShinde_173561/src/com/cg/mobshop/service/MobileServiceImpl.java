package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl {
	MobileDAOImpl dao = new MobileDAOImpl();
	
	public Map<Integer,Mobiles> getMobilesList() {
		return dao.getMobilesList();
	}

	public Mobiles deleteMobile(int mobcode) {
		return dao.deleteMobile(mobcode);
	}

	public List<Mobiles> SortList(int criteria) {
		
		
		return dao.SortList(criteria);
	}
	


}
