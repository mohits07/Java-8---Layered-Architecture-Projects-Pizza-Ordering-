package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {

	public static void main(String[] args) {
		// Creating Service class object
		IPizzaOrderService service = new PizzaOrderService();

		// Creating Scanner obj and temporary variables
		Scanner sc = new Scanner(System.in);
		int menuChoice, orderId;
		String toppingChoice;
		String customerName, address, phone;
		boolean isMobileNoValid;

		// Creating objects of bean classes
		Customer customer = new Customer();
		PizzaOrder pizza = new PizzaOrder();

		System.out.println("Welcome");

		// creating infinite loop, this loop will end when user selects exit and
		// program will terminate
		while (true) {
			// Displaying menu
			System.out.println("1) Place Order");
			System.out.println("2) Display Order");
			System.out.println("3) Exit");

			// user can select only one of above choice
			menuChoice = sc.nextInt();
			switch (menuChoice) {

			case 1:

				// asking customer details and populating Customer class object
				System.out.println("Enter the name of the customer:");
				customerName = sc.next();
				customer.setCustomerName(customerName);
				System.out.println("Enter customer address:");
				address = sc.next();
				customer.setAddress(address);

				while (true) {
					System.out.println("Enter customer phone number:");
					phone = sc.next();
					isMobileNoValid = service.validateMobileNumber(phone);
					if (isMobileNoValid == true) {
						customer.setPhone(phone);
						break;
					} else {
						System.out
								.println("Mobile number should be 10 digits and start with 7/8/9");
					}
				}

				// asking order details and populating PizzaOrder class object
				int pizzaPrice = 0;
				System.out.println("Pizza Toppings \t Price(in Rs)");
				System.out.println("------------------------------");
				System.out.println("Capsicum \t 30");
				System.out.println("Mushroom \t 50");
				System.out.println("Jalapeno \t 70");
				System.out.println("Paneer   \t 85");
				System.out.println("Type of Pizza Topping preferred:");

				toppingChoice = sc.next();

				try {
					pizzaPrice = service.calculatePizzaPrice(toppingChoice);
					System.out.println("Price: " + pizzaPrice);
					pizza.setTotalPrice(pizzaPrice);
					// System.out.println("Do you want to confirm the order? (y/n)");
					System.out.println("Order Date: " + LocalDate.now());

					// placing order
					orderId = service.placeOrder(customer, pizza);
					System.out
							.println("Pizza order successfully placed with order Id: "
									+ orderId);
				} catch (PizzaException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;

			case 2:
				System.out.println("Enter order Id:");
				orderId = sc.nextInt();

				// getting order details for the given orderId
				try {
					pizza = service.getOrderDetails(orderId);
					System.out.println(pizza);
				} catch (PizzaException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// displaying order details by calling toString() method of
				// PizzaOrder class
				
				break;

			case 3:
				// greeting user and exiting application
				System.out.println("Thanks for visiting, come again");
				System.exit(1);

			default:
				try {
					throw new PizzaException("Invalid choice");
		            
				} catch (PizzaException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
