package com.cg.pizzaorder.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class getOrderDetailsTest {

	IPizzaOrderService service=null;
	
	@Before
	public void setUp(){
		service= new PizzaOrderService();
	}
	
	@Test
	public void checkgGetOrderDetails(){
		PizzaOrder po = null;
		Customer customer= new Customer();
		
		PizzaOrder pizza = new PizzaOrder();
		
		pizza.setOrderId(123);
		
		service.placeOrder(customer, pizza);
		try {
			int orderId=123;
			po=service.getOrderDetails(orderId);
		} catch (PizzaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNull(po);
	}
	
	@After
	public void destroy(){
		service=null;
	}
}
