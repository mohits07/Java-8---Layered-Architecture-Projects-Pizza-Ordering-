package com.capgemini.axis.test;


import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.axis.bean.Customer;
import com.capgemini.axis.exception.CustomerExists;
import com.capgemini.axis.exception.CustomerNotFound;
import com.capgemini.axis.service.IService;
import com.capgemini.axis.service.IServiceClass;



public class DepositTest {
IService service = null;

	@Before
	public void setUp() throws Exception {
		service = new IServiceClass();
	}

	// right inputs
	@Test
	public void checkDeposit() {
		try {
			Customer customer = new Customer("Tushar", "t@g.c", "8286703935",
					"password", 5000);
	;

			String result = service.deposit(customer, 2000);
			assertNotNull(result);
		} catch (CustomerNotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// wrong inputs
	// should print no user as user don't exists in console
	@Test
	public void checkDeposit2() {
		try {
			Customer customer = new Customer();
			
			service.checkUser(customer.getMobileno(),
					customer.getPassword());
			String result = service.deposit(customer, 9000);
			assertNotNull(result);
		}  catch (CustomerNotFound e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}

