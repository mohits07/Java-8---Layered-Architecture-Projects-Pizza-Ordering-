package com.capgemini.axis.dao;

import java.util.List;

import com.capgemini.axis.bean.Customer;
import com.capgemini.axis.bean.Transaction;
import com.capgemini.axis.exception.CustomerExists;
import com.capgemini.axis.exception.CustomerNotFound;
import com.capgemini.axis.exception.InsufficientBalanceExeption;

public interface IDao {
	//method used for implementation
	
	Customer createCustomer(Customer customer) throws CustomerExists;

	String withdraw(Customer customer, double amount)
			throws InsufficientBalanceExeption; 

	String deposit(Customer customer, double amount) throws CustomerNotFound;

	Customer checkUser(String username, String password)
			throws CustomerNotFound;

	List<Transaction> printTransaction(Customer customer);

	double checkBalance(Customer customer);

	long ids = 10002;
	
	//jdbc implementation query methods
	String insertCustomer =                        // Customer table description
			"insert into customer"
			+ "(customerID,name,email,"
			+ "mobileNumber,password,"
			+ "balance)"
			+ " values"
			+ "(?,?,?,?,?,?)";
	
	String insertTransaction = "insert into transactions"   //transaction table description
			+ "(tid,mobno,type,amount,balance)"
			+ " values"
			+ "(tid_seq.nextval,?,?,?,?)";                // for transaction id generation
	
	String findUser = "select * from customer where mobilenumber=? and password=?";
	
	String getLastestId = "SELECT MAX(customerID)FROM customer";
	
	String checkIfUserExists = "SELECT COUNT(customerID) FROM customer where mobilenumber=?";
	
	String withDrawMoney = "UPDATE customer SET balance=? WHERE customerid=?";
	
	String depositMoney = "UPDATE customer SET balance=? WHERE mobilenumber=?";
	
	String findReciever = "select * from customer where mobilenumber=?";
	
	String findTransaction = "SELECT * FROM transactions WHERE mobno=?";

	Customer isValidUser(String mobileNumber) throws CustomerNotFound;
}
