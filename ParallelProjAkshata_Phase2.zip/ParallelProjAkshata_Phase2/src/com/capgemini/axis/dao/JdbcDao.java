package com.capgemini.axis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.capgemini.axis.bean.Customer;
import com.capgemini.axis.bean.Transaction;
import com.capgemini.axis.config.JdbcConfig;
import com.capgemini.axis.exception.CustomerExists;
import com.capgemini.axis.exception.CustomerNotFound;
import com.capgemini.axis.exception.InsufficientBalanceExeption;
import com.capgemini.axis.service.TransactionComparator;


public class JdbcDao implements IDao {

	Connection connection = null;
	PreparedStatement statement = null;
	long newID = 0;

	public JdbcDao() {
		try {
			this.connection = JdbcConfig.getConnection();
			statement = connection.prepareStatement(getLastestId);

			ResultSet set = statement.executeQuery();
			if (set.next() && set.getLong(1)!=0)
				this.newID = set.getLong(1);
			else
				this.newID = ids;				
		} catch (Exception e) {
			System.out.println("from constructor " + e.getMessage());
		}
	}

	@Override
	public Customer createCustomer(Customer customer) throws CustomerExists {

		try {
			statement = connection.prepareStatement(checkIfUserExists);
			statement.setString(1, customer.getMobileno());
			ResultSet set = statement.executeQuery();

			if (set.next() && set.getInt(1) < 1) {

				customer.setId(++newID);

				statement = connection.prepareStatement(insertCustomer);
				statement.setLong(1, (long) customer.getId());
				statement.setString(2, customer.getName());
				statement.setString(3, customer.getEmail());
				statement.setString(4, customer.getMobileno());
				statement.setString(5, customer.getPassword());
				statement.setDouble(6, customer.getBalance());
				statement.executeUpdate();

				statement = connection.prepareStatement(insertTransaction);
				statement.setString(1, customer.getMobileno());
				statement.setString(2, "CR");
				statement.setDouble(3, customer.getBalance());
				statement.setDouble(4, customer.getBalance());
				statement.executeUpdate();
				return customer;
			} else {
				throw new CustomerExists("Customer Already Exists. Please Login");
			}
		} catch (Exception e) {
			//SQL Exception
			throw new CustomerExists(e.getMessage());
		}
	}

	@Override
	public String withdraw(Customer customer, double amount)
			throws InsufficientBalanceExeption {

		try {
			if (amount <= customer.getBalance() - 100) {
				
				//obj set
				statement = connection.prepareStatement(withDrawMoney);
				statement.setDouble(1,customer.getBalance()-amount);
				statement.setLong(2, (long) customer.getId());
				statement.executeUpdate();
				
				customer.setBalance(customer.getBalance()-amount);
				
				//store in transaction
				statement = connection.prepareStatement(insertTransaction);
				statement.setString(1, customer.getMobileno());
				statement.setString(2, "DB");
				statement.setDouble(3, amount);
				statement.setDouble(4, customer.getBalance());
				statement.executeUpdate();
				
				return "Rs." + amount + " debited from account "
						+ customer.getId() + " on "
						+ LocalDateTime.now() + "\nNew Balance is Rs."
						+ customer.getBalance();
			} else
				throw new InsufficientBalanceExeption(
						"You Have Insufficient Fund.");
		} catch (Exception e) {
			throw new InsufficientBalanceExeption(e.getMessage());
		}
	}

	@Override
	public String deposit(Customer customer, double amount) 
	throws CustomerNotFound{
		try
		{	
			statement = connection.prepareStatement(depositMoney);
			statement.setDouble(1,customer.getBalance()+amount);
			statement.setString(2, customer.getMobileno());
			statement.executeUpdate();
			
			customer.setBalance(customer.getBalance()+amount);
			
			//store in transaction
			statement = connection.prepareStatement(insertTransaction);
			statement.setString(1, customer.getMobileno());
			statement.setString(2, "CR");
			statement.setDouble(3, amount);
			statement.setDouble(4, customer.getBalance());
			statement.executeUpdate();
			
			return "Rs." + amount + " credited on account "
			+ customer.getId() + " on " + LocalDateTime.now()
			+ "\nNew Balance is Rs." + customer.getBalance();
			
		}catch(Exception e)
		{
			throw new CustomerNotFound(e.getMessage());
		}
	}

	@Override
	public Customer checkUser(String username, String password)
			throws CustomerNotFound {
		try {
			Customer customer = new Customer();
			statement = connection.prepareStatement(findUser);
			statement.setString(1, username);
			statement.setString(2, password);
			statement.executeUpdate();

			ResultSet set = statement.getResultSet();
			//if user exists
			if (set.next()) {
				customer.setId(set.getLong(1));
				customer.setName(set.getString(2));
				customer.setEmail(set.getString(3));
				customer.setMobileno(set.getString(4));
				customer.setPassword(set.getString(5));
				customer.setBalance(set.getDouble(6));
				return customer;
			} else
				throw new CustomerNotFound("No User Found");
		} catch (Exception e) {
			throw new CustomerNotFound(e.getMessage());
		}
	}

	@Override
	public List<Transaction> printTransaction(Customer customer) {
		List<Transaction> summaryList = new ArrayList();
		try {
			statement = connection.prepareStatement(findTransaction);
			statement.setString(1, customer.getMobileno());
			ResultSet set = statement.executeQuery();
			while(set.next())
			{
				Transaction trans = new Transaction(
						set.getString(2),set.getString(3),
						set.getDouble(4),set.getDouble(5)
						);
				summaryList.add(trans);
			}
			return summaryList;
		} catch (Exception e) {
			summaryList.add(new Transaction("ERROR",e.getMessage(),0,0));
			return summaryList;
		}
	}

	@Override
	public double checkBalance(Customer customer) {
		return customer.getBalance();
	}

	@Override
	public Customer isValidUser(String mobileNumber)
			throws CustomerNotFound {
		
		try
		{
			Customer customer = new Customer();
			statement = connection.prepareStatement(findReciever);
			statement.setString(1, mobileNumber);
			statement.executeUpdate();
			ResultSet set = statement.getResultSet();
			if (set.next()) {
				customer.setId(set.getLong(1));
				customer.setName(set.getString(2));
				customer.setEmail(set.getString(3));
				customer.setMobileno(set.getString(4));
				customer.setPassword(set.getString(5));
				customer.setBalance(set.getDouble(6));
				return customer;
			} else
				throw new CustomerNotFound("No User Found");
		}catch(Exception e)
		{
			throw new CustomerNotFound(e.getMessage());
		}
	}

	
}