package com.capgemini.axis.exception;

public class InsufficientBalanceExeption extends Exception {

	public InsufficientBalanceExeption() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientBalanceExeption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
