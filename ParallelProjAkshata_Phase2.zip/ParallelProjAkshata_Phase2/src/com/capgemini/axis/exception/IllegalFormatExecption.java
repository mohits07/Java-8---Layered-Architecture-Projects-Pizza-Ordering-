package com.capgemini.axis.exception;

public class IllegalFormatExecption extends Exception {

	public IllegalFormatExecption() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IllegalFormatExecption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
