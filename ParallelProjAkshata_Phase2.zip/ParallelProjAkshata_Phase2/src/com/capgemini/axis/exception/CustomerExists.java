package com.capgemini.axis.exception;

public class CustomerExists extends Exception {

	public CustomerExists() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerExists(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
