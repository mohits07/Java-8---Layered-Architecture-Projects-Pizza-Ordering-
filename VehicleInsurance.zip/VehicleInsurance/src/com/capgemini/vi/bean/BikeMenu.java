package com.capgemini.vi.bean;

public class BikeMenu {
	private String bikeName;
	private int engModel;
	private double bikePrice;
	private String bikeYear;
	
	public BikeMenu(String bikeName, int engModel, double bikePrice) {
		super();
		this.bikeName = bikeName;
		this.engModel = engModel;
		this.bikePrice = bikePrice;
		//this.bikeYear = bikeYear;
	}
	public String getBikeYear() {
		return bikeYear;
	}
	public void setBikeYear(String bikeYear) {
		this.bikeYear = bikeYear;
	}
	public String getBikeName() {
		return bikeName;
	}
	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}
	public int getEngModel() {
		return engModel;
	}
	public void setEngModel(int engModel) {
		this.engModel = engModel;
	}
	public double getBikePrice() {
		return bikePrice;
	}
	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}
	@Override
	public String toString() {
		return "BikeMenu [bikeName=" + bikeName + ", engModel=" + engModel
				+ ", bikePrice=" + bikePrice + ", bikeYear=" + bikeYear + "]";
	}
	
	
}
