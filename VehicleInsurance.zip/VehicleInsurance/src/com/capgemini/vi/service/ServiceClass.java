package com.capgemini.vi.service;

import com.capgemini.vi.bean.BikeMenu;
import com.capgemini.vi.doa.DoaClass;
import com.capgemini.vi.doa.DoaInterface;



public class ServiceClass implements ServiceInterface {
	DoaInterface db= new DoaClass();
	String currentYear="2019";
	
	
	public void addBike(BikeMenu bike) {//method to add bikes to list
		db.addBike(bike);
	}
	
	public double calculatePremiumOf3rdParty(BikeMenu b) {  //method to calculate 3rd party premium
		
		int depPercent=5; // Depreciation interest based on age of bike 2cases
		int depPercent2=10;
		
		double temp = b.getBikePrice();
		 
		int noOfYears = Integer.parseInt(currentYear)-Integer.parseInt(b.getBikeYear());
		if(noOfYears>3){                                  
			double temp2,temp1 = 0;        
		for(int i=0;i<3;i++){
			 temp1=((100-depPercent)*temp)/100;
			 
		}
		
		temp2=temp1;
		for(int i=0;i<=noOfYears-3;i++){
			temp2=((100-depPercent2)*temp2)/100;
		}
		return temp2*0.03;
		}
		
		else{
			double temp2 = 0,temp1;
			for(int i=0;i<=noOfYears;i++){
				 temp2=((100-depPercent)*temp)/100;
				 
			}
			return temp2*0.03;   //deppercent is 0.03 fr 3rd party
		}
		
		
		
		
	}
	
	
	
	public double calculatePremiumComprehensive(BikeMenu b){   //method to calculate 3rd party premium
		double deppercent = 5;
		double deppercent2 = 10;
		double temp = b.getBikePrice();
		
		int noOfYears = Integer.parseInt(currentYear)-Integer.parseInt(b.getBikeYear());
		if(noOfYears>3){
			double temp2 = 0,temp1 = 0;
		for(int i=0;i<3;i++){
			 temp1=((100-deppercent)*temp)/100;
			 
		}
		
		temp2=temp1;
		for(int i=0;i<=noOfYears-3;i++){
			temp2=((100-deppercent2)*temp2)/100;
		}
		return temp2*0.05;
		}
		
		else{
			double temp2 = 0,temp1 = 0;
			for(int i=0;i<=noOfYears;i++){
				 temp2=((100-deppercent)*temp2)/100;
				 
			}
			return temp2*0.05;  //deppercent is 0.05 for comprehensive
		}
		
//		double premium = temp2*0.05;
		
		
		
		//double depriciatedValue = b.getPrice().
		
	}

	
}
