package com.capgemini.vi.service;

import com.capgemini.vi.bean.BikeMenu;

public interface ServiceInterface {

	void addBike(BikeMenu bike1);


	double calculatePremiumComprehensive(BikeMenu bike1);

	public double calculatePremiumOf3rdParty(BikeMenu b);
}
