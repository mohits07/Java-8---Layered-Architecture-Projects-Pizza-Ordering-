package com.capgemini.vi.ui;

import java.util.Scanner;




import com.capgemini.vi.bean.BikeMenu;
import com.capgemini.vi.service.ServiceClass;
import com.capgemini.vi.service.ServiceInterface;

public class UserInterface {
 public static void main(String[] args) {
	 Scanner scan =  new Scanner(System.in);
	 String year;
	 String bikeYear;
	 double premium;
	 String currentYear = "2019";
	 ServiceInterface service = new ServiceClass();
	 
	 BikeMenu bike1 = new BikeMenu("KTM" , 250, 150000);
	 BikeMenu bike2 = new BikeMenu("PULSAR" , 220, 120000);
	 BikeMenu bike3 = new BikeMenu("CBR" , 150, 110000);
	 BikeMenu bike4 = new BikeMenu("UNICORN" , 150, 90000);
	 BikeMenu bike5 = new BikeMenu("Splendor" , 100, 60000);
	 
	System.out.println("Welcome to VI insurace");
	System.out.println("please select the model from the below menu");
	System.out.println("1)KTM 250 \n2)PULSAR 220 \n3)CBR 150 \n4)UNICORN 150 \n5)Splendor 110");
	System.out.println("Please enter valid,choice");
	int choice= scan.nextInt() ;
	
	switch (choice){
		case 1: {
			System.out.println("Enter the Bike Registration year:");
			year = scan.next();
			bike1.setBikeYear(year);
			service.addBike(bike1);
			System.out.println("following are the types of Insurance available:\n1.Third party\2.Comprehensive");
			System.out.println("Please choose any 1 of the above options");
			
			int choice2 = scan.nextInt();
			if(choice2==1){
				premium = service.calculatePremiumOf3rdParty(bike1);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice2==2){
				premium = service.calculatePremiumComprehensive(bike1);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
			
			break;
		}
		case 2:{
			System.out.println("Enter bike registration year");
			year = scan.next();
			bike2.setBikeYear(year);
			service.addBike(bike2);
			System.out.println("following are the types of Insurance available:\n1.Third party\2.Comprehensive");
			System.out.println("Please choose any 1 of the above options");
			
			int choice2 = scan.nextInt();
			if(choice2==1){
				premium = service.calculatePremiumOf3rdParty(bike1);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice2==2){
				premium = service.calculatePremiumComprehensive(bike1);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
			break;
		}
		case 3:{
			System.out.println("Enter bike registratoin year");
			year = scan.next();
			bike3.setBikeYear(year);
			service.addBike(bike3);
			int choice2 = scan.nextInt();
			if(choice2==1){
				premium = service.calculatePremiumOf3rdParty(bike1);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice2==2){
				premium = service.calculatePremiumComprehensive(bike1);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
			break;
		}
		case 4:{
			System.out.println("Enter bike registratoin year");
			year = scan.next();
			bike4.setBikeYear(year);
			service.addBike(bike4);
			int choice2 = scan.nextInt();
			if(choice2==1){
				premium = service.calculatePremiumOf3rdParty(bike1);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice2==2){
				premium = service.calculatePremiumComprehensive(bike1);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
			break;
		}
		case 5:{
					System.out.println("Enter bike registratoin year");
					year = scan.next();
					bike5.setBikeYear(year);
					service.addBike(bike5);
					int choice2 = scan.nextInt();
					if(choice2==1){
						premium = service.calculatePremiumOf3rdParty(bike1);
						System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
					}
					else if(choice2==2){
						premium = service.calculatePremiumComprehensive(bike1);
						System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
					}
					break;
		}
	}
	
}
}
