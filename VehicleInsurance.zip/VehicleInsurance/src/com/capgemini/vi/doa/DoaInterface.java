package com.capgemini.vi.doa;

import com.capgemini.vi.bean.BikeMenu;



public interface DoaInterface {
//	public void BikeMenu addBike(BikeMenu Bike);

	void addBike(BikeMenu bike);
	
}
