package com.capgemini.vi.doa;

import java.util.ArrayList;
import java.util.List;


import com.capgemini.vi.bean.BikeMenu;



public class DoaClass implements DoaInterface {
	
	
	List<BikeMenu> bikeDB= new ArrayList<BikeMenu>();
	
	public void addBike(BikeMenu b){
				bikeDB.add(b);
				for (BikeMenu bikesInfo : bikeDB) {
					System.out.println(bikesInfo.toString());
	}
		
	
}
	}
